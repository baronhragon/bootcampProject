"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_ganador_ganador_module_ts"],{

/***/ 905:
/*!***************************************************!*\
  !*** ./src/app/ganador/ganador-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GanadorPageRoutingModule": () => (/* binding */ GanadorPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ganador_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ganador.page */ 233);




const routes = [
    {
        path: '',
        component: _ganador_page__WEBPACK_IMPORTED_MODULE_0__.GanadorPage
    }
];
let GanadorPageRoutingModule = class GanadorPageRoutingModule {
};
GanadorPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GanadorPageRoutingModule);



/***/ }),

/***/ 2653:
/*!*******************************************!*\
  !*** ./src/app/ganador/ganador.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GanadorPageModule": () => (/* binding */ GanadorPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ganador_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ganador-routing.module */ 905);
/* harmony import */ var _ganador_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ganador.page */ 233);







let GanadorPageModule = class GanadorPageModule {
};
GanadorPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ganador_routing_module__WEBPACK_IMPORTED_MODULE_0__.GanadorPageRoutingModule
        ],
        declarations: [_ganador_page__WEBPACK_IMPORTED_MODULE_1__.GanadorPage]
    })
], GanadorPageModule);



/***/ }),

/***/ 233:
/*!*****************************************!*\
  !*** ./src/app/ganador/ganador.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GanadorPage": () => (/* binding */ GanadorPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ganador_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ganador.page.html?ngResource */ 4718);
/* harmony import */ var _ganador_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ganador.page.scss?ngResource */ 9543);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let GanadorPage = class GanadorPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    Rechazar() {
        this.router.navigate(['/rechazar']);
    }
    Home() {
        this.router.navigate(['/home']);
    }
    Carta() {
        this.router.navigate(['/carta']);
    }
};
GanadorPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
GanadorPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-ganador',
        template: _ganador_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ganador_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GanadorPage);



/***/ }),

/***/ 9543:
/*!******************************************************!*\
  !*** ./src/app/ganador/ganador.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "h3, .botones {\n  width: 90%;\n  margin: 0 auto;\n}\n\n.title {\n  padding-top: 0;\n}\n\n.contenedor {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  text-align: center;\n  gap: 2em;\n  padding-top: 50%;\n}\n\n.botones ion-button {\n  margin-right: 1.4em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdhbmFkb3IucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsVUFBQTtFQUNBLGNBQUE7QUFDRjs7QUFDQTtFQUNFLGNBQUE7QUFFRjs7QUFBQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxnQkFBQTtBQUdGOztBQUFFO0VBQ0UsbUJBQUE7QUFHSiIsImZpbGUiOiJnYW5hZG9yLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImgzLCAuYm90b25lcyB7XHJcbiAgd2lkdGg6IDkwJTtcclxuICBtYXJnaW46IDAgYXV0bztcclxufVxyXG4udGl0bGUge1xyXG4gIHBhZGRpbmctdG9wOiAwO1xyXG59XHJcbi5jb250ZW5lZG9yIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgZ2FwOiAyZW07XHJcbiAgcGFkZGluZy10b3A6IDUwJTtcclxufVxyXG4uYm90b25lcyB7XHJcbiAgaW9uLWJ1dHRvbiB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEuNGVtO1xyXG4gIH1cclxufSJdfQ== */";

/***/ }),

/***/ 4718:
/*!******************************************************!*\
  !*** ./src/app/ganador/ganador.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"close\" id=\"flechita-atras\" (click)=\"Home()\"></ion-icon>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content class=\"contenedor\">\r\n \r\n  <div class=\"contenedor\">\r\n    <h3>The winning restaurant is:</h3>\r\n    <h1 class=\"title\">Josephinos</h1>\r\n  \r\n    <div class=\"botones\">\r\n      <ion-button color=\"danger\" (click)=\"Rechazar()\" expand=\"round\">Cancel invitation</ion-button>\r\n      <ion-button color=\"secondary\" expand=\"round\" (click)=\"Carta()\">Confirm invitation</ion-button>\r\n    </div>\r\n  </div>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_ganador_ganador_module_ts.js.map