"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_historial_historial_module_ts"],{

/***/ 4996:
/*!*******************************************************!*\
  !*** ./src/app/historial/historial-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialPageRoutingModule": () => (/* binding */ HistorialPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _historial_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./historial.page */ 8594);




const routes = [
    {
        path: '',
        component: _historial_page__WEBPACK_IMPORTED_MODULE_0__.HistorialPage
    }
];
let HistorialPageRoutingModule = class HistorialPageRoutingModule {
};
HistorialPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HistorialPageRoutingModule);



/***/ }),

/***/ 7067:
/*!***********************************************!*\
  !*** ./src/app/historial/historial.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialPageModule": () => (/* binding */ HistorialPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _historial_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./historial-routing.module */ 4996);
/* harmony import */ var _historial_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./historial.page */ 8594);







let HistorialPageModule = class HistorialPageModule {
};
HistorialPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _historial_routing_module__WEBPACK_IMPORTED_MODULE_0__.HistorialPageRoutingModule
        ],
        declarations: [_historial_page__WEBPACK_IMPORTED_MODULE_1__.HistorialPage]
    })
], HistorialPageModule);



/***/ }),

/***/ 8594:
/*!*********************************************!*\
  !*** ./src/app/historial/historial.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistorialPage": () => (/* binding */ HistorialPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _historial_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./historial.page.html?ngResource */ 8289);
/* harmony import */ var _historial_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./historial.page.scss?ngResource */ 3018);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let HistorialPage = class HistorialPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    Home() {
        this.router.navigate(['/home']);
    }
};
HistorialPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
HistorialPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-historial',
        template: _historial_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_historial_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HistorialPage);



/***/ }),

/***/ 3018:
/*!**********************************************************!*\
  !*** ./src/app/historial/historial.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".pedido {\n  gap: 1.5em;\n  margin-bottom: 2em;\n  box-shadow: none !important;\n  border-bottom: 1px solid var(--ion-color-light);\n}\n.pedido .imagen-historial {\n  margin-right: 1em;\n}\n.pedido .imagen-historial img {\n  object-fit: cover;\n  height: 100%;\n  width: 100%;\n  border-radius: 2em;\n  box-shadow: 0 0.5em 1em var(--ion-color-medium);\n}\n.pedido .pedido-info {\n  display: flex;\n  flex-direction: column;\n}\n.pedido h2 {\n  margin: 0;\n}\n.pedido h3, .pedido h4 {\n  text-align: left;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhpc3RvcmlhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQkFBQTtFQUNBLCtDQUFBO0FBQ0o7QUFDQTtFQUNJLGlCQUFBO0FBQ0o7QUFBSTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLCtDQUFBO0FBRVI7QUFDSTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtBQUNSO0FBRUk7RUFDRyxTQUFBO0FBQVA7QUFFSTtFQUNJLGdCQUFBO0VBQ0EsU0FBQTtBQUFSIiwiZmlsZSI6Imhpc3RvcmlhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucGVkaWRvIHtcclxuICAgIGdhcDogMS41ZW07XHJcbiAgICBtYXJnaW4tYm90dG9tOiAyZW07XHJcbiAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuXHJcbi5pbWFnZW4taGlzdG9yaWFsIHtcclxuICAgIG1hcmdpbi1yaWdodDogMWVtO1xyXG4gICAgaW1nIHtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMmVtO1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDAgMC41ZW0gMWVtIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgfVxyXG59XHJcbiAgICAucGVkaWRvLWluZm8ge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIH1cclxuXHJcbiAgICBoMiB7XHJcbiAgICAgICBtYXJnaW46IDA7XHJcbiAgICB9XHJcbiAgICBoMyxoNCB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 8289:
/*!**********************************************************!*\
  !*** ./src/app/historial/historial.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"arrow-back-outline\" id=\"flechita-atras\" (click)=\"Home()\"></ion-icon>\r\n  </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"contenedor\">\r\n    <h1 class=\"title\">Your recent reservations</h1>\r\n    <p  class=\"description\">View the details of your most recent reseervation</p>\r\n  <div class=\"pedidos\">\r\n\r\n    <ion-card class=\"pedido\">\r\n\r\n      <ion-row>\r\n\r\n        <ion-col size-lg=\"2\" size-md=\"3\" size-sm=\"3\" size-xs=\"4\">\r\n          <div class=\"imagen-historial\">\r\n            <img src=\"../../assets/restaurant1.jpeg\" alt=\"\" srcset=\"\">\r\n          </div>\r\n        </ion-col>\r\n\r\n        <ion-col>\r\n          <div class=\"pedido-info\">\r\n            <ion-card-title> <h2>Restaurant</h2> </ion-card-title>\r\n            <ion-card-subtitle> <h3>1 item | MXN 100</h3> </ion-card-subtitle>\r\n            <ion-card-subtitle> <h3>28 may, Completed</h3> </ion-card-subtitle>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n    </ion-card>\r\n\r\n  </div>\r\n</div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_historial_historial_module_ts.js.map