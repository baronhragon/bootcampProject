"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_seleccion-restaurante_seleccion-restaurante_module_ts"],{

/***/ 6519:
/*!*******************************************************************************!*\
  !*** ./src/app/seleccion-restaurante/seleccion-restaurante-routing.module.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeleccionRestaurantePageRoutingModule": () => (/* binding */ SeleccionRestaurantePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _seleccion_restaurante_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./seleccion-restaurante.page */ 8429);




const routes = [
    {
        path: '',
        component: _seleccion_restaurante_page__WEBPACK_IMPORTED_MODULE_0__.SeleccionRestaurantePage
    }
];
let SeleccionRestaurantePageRoutingModule = class SeleccionRestaurantePageRoutingModule {
};
SeleccionRestaurantePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SeleccionRestaurantePageRoutingModule);



/***/ }),

/***/ 1732:
/*!***********************************************************************!*\
  !*** ./src/app/seleccion-restaurante/seleccion-restaurante.module.ts ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeleccionRestaurantePageModule": () => (/* binding */ SeleccionRestaurantePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _seleccion_restaurante_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./seleccion-restaurante-routing.module */ 6519);
/* harmony import */ var _seleccion_restaurante_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./seleccion-restaurante.page */ 8429);







let SeleccionRestaurantePageModule = class SeleccionRestaurantePageModule {
};
SeleccionRestaurantePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _seleccion_restaurante_routing_module__WEBPACK_IMPORTED_MODULE_0__.SeleccionRestaurantePageRoutingModule
        ],
        declarations: [_seleccion_restaurante_page__WEBPACK_IMPORTED_MODULE_1__.SeleccionRestaurantePage]
    })
], SeleccionRestaurantePageModule);



/***/ }),

/***/ 8429:
/*!*********************************************************************!*\
  !*** ./src/app/seleccion-restaurante/seleccion-restaurante.page.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SeleccionRestaurantePage": () => (/* binding */ SeleccionRestaurantePage)
/* harmony export */ });
/* harmony import */ var C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _seleccion_restaurante_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./seleccion-restaurante.page.html?ngResource */ 2385);
/* harmony import */ var _seleccion_restaurante_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./seleccion-restaurante.page.scss?ngResource */ 5693);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _modal_invitacion_modal_invitacion_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modal-invitacion/modal-invitacion.page */ 9285);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service.service */ 9353);









let SeleccionRestaurantePage = class SeleccionRestaurantePage {
  constructor(router, modalController, api) {
    this.router = router;
    this.modalController = modalController;
    this.api = api;
    this.results = [];
    this.imagesUrl = "http://74.208.181.113:3000/images/";
    this.current = [];
    this.option = {
      slidesPerView: 1.8,
      centeredSlides: true,
      loop: true,
      spaceBetween: 10
    };
    this.optionTypes = {
      slidesPerView: 3,
      centeredSlides: true,
      spaceBetween: 10,
      loop: true
    };
  }

  ngOnInit() {
    this.restaurantsGet();
  }

  openModalInv() {
    var _this = this;

    return (0,C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalController.create({
        component: _modal_invitacion_modal_invitacion_page__WEBPACK_IMPORTED_MODULE_3__.ModalInvitacionPage,
        initialBreakpoint: 0.6,
        breakpoints: [0, 0.6],
        cssClass: 'modal'
      });
      return yield modal.present();
    })();
  }

  openfilter() {
    this.router.navigate(['/modal-filter']);
  }

  Contactos() {
    this.router.navigate(['/contactos']);
  }

  Votacion() {
    localStorage.setItem("selection", JSON.stringify(this.current));
    this.router.navigate(['/seleccion-invitado']);
  }

  restaurantsGet() {
    this.api.restaurantsGet().subscribe(responseFromTheServer => {
      let responseLocal;
      responseLocal = responseFromTheServer;
      this.results = responseLocal.recordset;
    });
  }

  Carta(i) {
    this.current.push(this.results[i]);
    console.log(this.current); // console.log(this.results[i].idRestaurant);
    // localStorage.setItem("IdRestaurant",JSON.stringify(this.results[i].idRestaurant))
    // console.log(this.results[i].idRestaurant);
  } // async openModalfilter(){
  //   const modal = await this.modalController.create({
  //     component: ModalFilterPage,
  //     cssClass:"modalFilter",
  //   });
  //   return await modal.present();
  // }


  toogleClass(restaurant) {
    restaurant.activate = !restaurant.activate;
  }

};

SeleccionRestaurantePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}, {
  type: _service_service__WEBPACK_IMPORTED_MODULE_4__.ApiService
}];

SeleccionRestaurantePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-seleccion-restaurante',
  template: _seleccion_restaurante_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_seleccion_restaurante_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], SeleccionRestaurantePage);


/***/ }),

/***/ 5693:
/*!**********************************************************************************!*\
  !*** ./src/app/seleccion-restaurante/seleccion-restaurante.page.scss?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = ".filtros-busqueda-home {\n  padding-bottom: 1.2em;\n  margin: 0 auto;\n}\n.filtros-busqueda-home .filtro-busqueda-home {\n  text-align: center;\n  width: auto;\n  cursor: pointer;\n}\n.filtros-busqueda-home .filtro-busqueda-home ion-card {\n  display: flex;\n  align-items: center;\n  background-color: var(--ion-color-light);\n  padding: 0 1.6em;\n  border-radius: 1.4em;\n  color: var(--ion-color-dark);\n  box-shadow: 0 0.2em 0.5em var(--ion-color-medium);\n  height: auto;\n  margin: 1.2vh;\n}\n.filtros-busqueda-home .filtro-busqueda-home ion-icon {\n  font-size: 1.8vh;\n  margin: 0;\n}\n.filtros-busqueda-home .filtro-busqueda-home p {\n  text-align: center;\n}\n.option_item .option_inner {\n  width: 100%;\n  height: 100%;\n  text-align: center;\n  cursor: pointer;\n  color: #585c68;\n  display: block;\n  border: 5px solid transparent;\n  position: relative;\n}\n.option_item .checkbox {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  z-index: 1;\n  opacity: 0;\n}\n.option_item .checkbox:checked ~ .option_inner {\n  border-color: red;\n}\n.tickmark {\n  position: absolute;\n  top: -1px;\n  left: -1px;\n  border: 20px solid;\n  border-color: #000 transparent transparent #000;\n}\n.restaurantes {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 2vh;\n}\n@media (min-width: 768px) {\n  .restaurantes {\n    display: grid;\n    grid-template-columns: 1fr 1fr 1fr;\n    gap: 2vh;\n  }\n}\n@media (min-width: 992px) {\n  .restaurantes {\n    display: grid;\n    grid-template-columns: 1fr 1fr 1fr 1fr;\n    gap: 2vh;\n  }\n}\n.restaurantes ion-card {\n  box-shadow: inset;\n  border-radius: 12px;\n}\n.restaurantes ion-card ion-card-content {\n  padding: 0;\n  margin: 0;\n}\n.restaurantes ion-card img {\n  object-fit: cover;\n  height: 250px;\n  width: auto;\n}\n.restaurantes ion-card ion-card-title {\n  margin: 1vh 0 0 0.6vh;\n  padding: 0;\n}\n.restaurantes ion-card ion-card-title h3 {\n  font-size: 2.2vh;\n  font-weight: bold;\n}\n.restaurantes ion-card .restaurante-calificacion {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.restaurantes ion-card ion-card-subtitle {\n  margin-left: 0.6vh;\n}\n.restaurantes ion-card ion-card-subtitle h4 {\n  font-size: 1.4vh;\n  color: var(--ion-color-medium);\n  margin: 0;\n  padding: 0;\n}\nion-card {\n  cursor: pointer;\n}\nion-card.bg-blue {\n  --background:blue;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGVjY2lvbi1yZXN0YXVyYW50ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDRSxxQkFBQTtFQUNBLGNBQUE7QUFBRjtBQUNFO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBbUJBLGVBQUE7QUFqQk47QUFETTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLDRCQUFBO0VBQ0EsaURBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQUdWO0FBRE07RUFDSSxnQkFBQTtFQUNBLFNBQUE7QUFHVjtBQURNO0VBQ0ksa0JBQUE7QUFHVjtBQUdBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7QUFBRjtBQUdBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0FBQUY7QUFHQTtFQUNFLGlCQUFBO0FBQUY7QUFHQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtFQUNBLCtDQUFBO0FBQUY7QUFHQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLFFBQUE7QUFBRjtBQUNFO0VBSkY7SUFLSSxhQUFBO0lBQ0Esa0NBQUE7SUFDQSxRQUFBO0VBRUY7QUFDRjtBQURFO0VBVEY7SUFVSSxhQUFBO0lBQ0Esc0NBQUE7SUFDQSxRQUFBO0VBSUY7QUFDRjtBQUhFO0VBTUUsaUJBQUE7RUFDQSxtQkFBQTtBQUFKO0FBTkk7RUFDRSxVQUFBO0VBQ0EsU0FBQTtBQVFOO0FBSEk7RUFDRSxpQkFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0FBS047QUFISTtFQUNBLHFCQUFBO0VBQ0EsVUFBQTtBQUtKO0FBSk07RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0FBTVI7QUFISTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBS047QUFISTtFQUNFLGtCQUFBO0FBS047QUFKTTtFQUNFLGdCQUFBO0VBQ0EsOEJBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtBQU1SO0FBQUE7RUFDRSxlQUFBO0FBR0Y7QUFEQTtFQUNFLGlCQUFBO0FBSUYiLCJmaWxlIjoic2VsZWNjaW9uLXJlc3RhdXJhbnRlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vYnVzcXVlZGEgcG9yIGZpbHRyb3NcclxuLmZpbHRyb3MtYnVzcXVlZGEtaG9tZSB7XHJcbiAgcGFkZGluZy1ib3R0b206IDEuMmVtO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIC5maWx0cm8tYnVzcXVlZGEtaG9tZSB7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgICAgIHBhZGRpbmc6IDAgMS42ZW07XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxLjRlbTtcclxuICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICAgICAgICBib3gtc2hhZG93OiAwIDAuMmVtIDAuNWVtIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgICAgICAgbWFyZ2luOiAxLjJ2aDtcclxuICAgICAgfVxyXG4gICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDEuOHZoO1xyXG4gICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICB9XHJcbiAgICAgIHAge1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICB9XHJcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbn1cclxuXHJcbi5vcHRpb25faXRlbSAub3B0aW9uX2lubmVyIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBjb2xvcjogIzU4NWM2ODtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBib3JkZXI6NXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLm9wdGlvbl9pdGVtIC5jaGVja2JveHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxMHB4O1xyXG4gIHJpZ2h0OiAxMHB4O1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgb3BhY2l0eTogMDtcclxufVxyXG5cclxuLm9wdGlvbl9pdGVtIC5jaGVja2JveDpjaGVja2VkIH4gLm9wdGlvbl9pbm5lcntcclxuICBib3JkZXItY29sb3I6cmVkO1xyXG59XHJcblxyXG4udGlja21hcmsge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6LTFweDtcclxuICBsZWZ0OiAtMXB4O1xyXG4gIGJvcmRlcjogMjBweCBzb2xpZDtcclxuICBib3JkZXItY29sb3I6ICMwMDAgdHJhbnNwYXJlbnQgdHJhbnNwYXJlbnQgIzAwMDtcclxufVxyXG5cclxuLnJlc3RhdXJhbnRlcyB7XHJcbiAgZGlzcGxheTogZ3JpZDtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7XHJcbiAgZ2FwOiAydmg7XHJcbiAgQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyIDFmcjtcclxuICAgIGdhcDogMnZoO1xyXG4gIH1cclxuICBAbWVkaWEgKG1pbi13aWR0aDogOTkycHgpIHtcclxuICAgIGRpc3BsYXk6IGdyaWQ7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyIDFmcjtcclxuICAgIGdhcDogMnZoO1xyXG4gIH1cclxuICBpb24tY2FyZCB7XHJcbiAgICBpb24tY2FyZC1jb250ZW50IHtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgbWFyZ2luOiAwO1xyXG4gICAgfVxyXG4gICAgLy9tYXgtaGVpZ2h0OiAyNGVtO1xyXG4gICAgYm94LXNoYWRvdzogaW5zZXQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMnB4O1xyXG4gICAgaW1ne1xyXG4gICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgaGVpZ2h0OiAyNTBweDtcclxuICAgICAgd2lkdGg6IGF1dG87XHJcbiAgICB9XHJcbiAgICBpb24tY2FyZC10aXRsZSB7XHJcbiAgICBtYXJnaW46IDF2aCAwIDAgMC42dmg7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgICBoMyB7XHJcbiAgICAgICAgZm9udC1zaXplOiAyLjJ2aDtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgfVxyXG4gICAgfSBcclxuICAgIC5yZXN0YXVyYW50ZS1jYWxpZmljYWNpb24ge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICBpb24tY2FyZC1zdWJ0aXRsZSB7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAwLjZ2aDtcclxuICAgICAgaDQge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMS40dmg7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICBwYWRkaW5nOiAwOyAgICBcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuaW9uLWNhcmQge1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5pb24tY2FyZC5iZy1ibHVlIHtcclxuICAtLWJhY2tncm91bmQ6Ymx1ZTtcclxufVxyXG4iXX0= */";

/***/ }),

/***/ 2385:
/*!**********************************************************************************!*\
  !*** ./src/app/seleccion-restaurante/seleccion-restaurante.page.html?ngResource ***!
  \**********************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon\r\n        name=\"arrow-back-outline\"\r\n        id=\"flechita-atras\"\r\n        (click)=\"Contactos()\"\r\n      ></ion-icon>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content force-overscroll id=\"body\">\r\n  <div class=\"contenedor\">\r\n    <h1 class=\"title\">Select 3 restaurants</h1>\r\n    <!-- barra de busqueda -->\r\n    <ion-searchbar\r\n      placeholder=\"What do you want to eat?\"\r\n      color=\"light\"\r\n    ></ion-searchbar>\r\n    <div class=\"restaurantes\">\r\n      <ion-card  *ngFor=\"let restaurant of results; let i = index\" [id]=\"restaurant['id']\">\r\n        <label class=\"option_item\">\r\n          <input type=\"checkbox\" class=\"checkbox\" (click)=\"Carta(i)\" />\r\n          <ion-grid class=\"option_inner\">\r\n              <img src=\"{{imagesUrl}}{{restaurant.img}}\" alt=\"asset\" />\r\n              <div class=\"restaurante-calificacion\">\r\n                <ion-card-title\r\n                  ><h3>{{restaurant.nameRestaurant}}</h3></ion-card-title\r\n                >\r\n              </div>\r\n              <ion-card-subtitle>\r\n                <h4 class=\"restaurante-categoria\">{{restaurant.rType}}</h4>\r\n              </ion-card-subtitle>\r\n          </ion-grid>\r\n        </label>\r\n      </ion-card>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n\r\n<ion-footer class=\"footer\">\r\n  <ion-button expand=\"round\" color=\"secondary\" (click)=\"Votacion()\"\r\n    >Accept</ion-button\r\n  >\r\n</ion-footer>\r\n\r\n<ion-fab horizontal=\"end\" vertical=\"center\" slot=\"fixed\">\r\n  <ion-fab-button (click)=\"openModalInv()\" color=\"secondary\">\r\n    <ion-icon name=\"eye\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_seleccion-restaurante_seleccion-restaurante_module_ts.js.map