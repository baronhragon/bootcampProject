"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_registro-menu_registro-menu_module_ts"],{

/***/ 9057:
/*!***************************************************************!*\
  !*** ./src/app/registro-menu/registro-menu-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroMenuPageRoutingModule": () => (/* binding */ RegistroMenuPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _registro_menu_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-menu.page */ 1839);




const routes = [
    {
        path: '',
        component: _registro_menu_page__WEBPACK_IMPORTED_MODULE_0__.RegistroMenuPage
    }
];
let RegistroMenuPageRoutingModule = class RegistroMenuPageRoutingModule {
};
RegistroMenuPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegistroMenuPageRoutingModule);



/***/ }),

/***/ 5950:
/*!*******************************************************!*\
  !*** ./src/app/registro-menu/registro-menu.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroMenuPageModule": () => (/* binding */ RegistroMenuPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _registro_menu_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-menu-routing.module */ 9057);
/* harmony import */ var _registro_menu_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-menu.page */ 1839);







let RegistroMenuPageModule = class RegistroMenuPageModule {
};
RegistroMenuPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _registro_menu_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistroMenuPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_registro_menu_page__WEBPACK_IMPORTED_MODULE_1__.RegistroMenuPage]
    })
], RegistroMenuPageModule);



/***/ }),

/***/ 1839:
/*!*****************************************************!*\
  !*** ./src/app/registro-menu/registro-menu.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroMenuPage": () => (/* binding */ RegistroMenuPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _registro_menu_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-menu.page.html?ngResource */ 2248);
/* harmony import */ var _registro_menu_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-menu.page.scss?ngResource */ 966);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service.service */ 9353);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 4497);







let RegistroMenuPage = class RegistroMenuPage {
    constructor(api, formBuilder, _sanitizer) {
        this.api = api;
        this.formBuilder = formBuilder;
        this._sanitizer = _sanitizer;
        this.currentFood = undefined;
        this.results = [];
        this.nameImg = "";
        this.registerMenuForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            nameProduct: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            descriptionProduct: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            price: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            productType: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
        });
    }
    ngOnInit() {
        this.api.restaurantsGet().subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
            this.results = responseLocal.recordset;
        });
    }
    handleChange(ev) {
        console.log(ev);
        this.currentFood = ev.target.value.idRestaurant;
    }
    onFile(event) {
        console.log(event);
        const [file] = event.target.files;
        this.dataImg = {
            fileRaw: file,
            fileName: file.name
        };
    }
    upload() {
        const data = new FormData();
        data.append('usrimage', this.dataImg.fileRaw);
        this.api.postImages(data).subscribe((resposeFromTheServer) => {
            let resposeLocal;
            resposeFromTheServer = resposeLocal;
        });
    }
    guardar() {
        let dataMenu = {
            nameProduct: this.registerMenuForm.value.nameProduct,
            descriptionProduct: this.registerMenuForm.value.descriptionProduct,
            price: this.registerMenuForm.value.price,
            productType: this.registerMenuForm.value.productType,
            img: this.dataImg.fileName,
            idRestaurant: this.currentFood
        };
        this.api.menuPost(dataMenu).subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
        });
        this.upload();
        this.registerMenuForm.reset();
    }
};
RegistroMenuPage.ctorParameters = () => [
    { type: _service_service__WEBPACK_IMPORTED_MODULE_2__.ApiService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.DomSanitizer }
];
RegistroMenuPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-registro-menu',
        template: _registro_menu_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_registro_menu_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegistroMenuPage);



/***/ }),

/***/ 966:
/*!******************************************************************!*\
  !*** ./src/app/registro-menu/registro-menu.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1tZW51LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 2248:
/*!******************************************************************!*\
  !*** ./src/app/registro-menu/registro-menu.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Menú</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item>\r\n      <ion-select\r\n        placeholder=\"Select Restaurant\"\r\n        (ionChange)=\"handleChange($event)\"\r\n      >\r\n        <ion-select-option *ngFor=\"let food of results\" [value]=\"food\"\r\n          >{{ food.nameRestaurant }}</ion-select-option\r\n        >\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Current value: {{ currentFood }}</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <form [formGroup]=\"registerMenuForm\" (ngSubmit)=\"guardar()\">\r\n    <ion-item>\r\n      <ion-label> Name Product </ion-label>\r\n      <ion-input formControlName=\"nameProduct\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label> Description </ion-label>\r\n      <ion-input formControlName=\"descriptionProduct\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label> Price</ion-label>\r\n      <ion-input formControlName=\"price\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label> Product Type </ion-label>\r\n      <ion-input formControlName=\"productType\"></ion-input>\r\n    </ion-item>\r\n  </form>\r\n  \r\n    <ion-item>\r\n      <ion-label> Image </ion-label>\r\n      <ion-input type=\"file\" (change)=\"onFile($event)\"></ion-input>\r\n    </ion-item>\r\n\r\n\r\n  <ion-button id=\"buttom\" (click)=\"guardar()\" expand=\"block\" shape=\"round\"\r\n    >Create</ion-button\r\n  >\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_registro-menu_registro-menu_module_ts.js.map