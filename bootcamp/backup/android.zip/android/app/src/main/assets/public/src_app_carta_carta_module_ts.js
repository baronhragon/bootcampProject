"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_carta_carta_module_ts"],{

/***/ 3882:
/*!***********************************************!*\
  !*** ./src/app/carta/carta-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartaPageRoutingModule": () => (/* binding */ CartaPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _carta_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carta.page */ 870);




const routes = [
    {
        path: '',
        component: _carta_page__WEBPACK_IMPORTED_MODULE_0__.CartaPage
    }
];
let CartaPageRoutingModule = class CartaPageRoutingModule {
};
CartaPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CartaPageRoutingModule);



/***/ }),

/***/ 3571:
/*!***************************************!*\
  !*** ./src/app/carta/carta.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartaPageModule": () => (/* binding */ CartaPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _carta_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carta-routing.module */ 3882);
/* harmony import */ var _carta_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carta.page */ 870);







let CartaPageModule = class CartaPageModule {
};
CartaPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _carta_routing_module__WEBPACK_IMPORTED_MODULE_0__.CartaPageRoutingModule
        ],
        declarations: [_carta_page__WEBPACK_IMPORTED_MODULE_1__.CartaPage]
    })
], CartaPageModule);



/***/ }),

/***/ 870:
/*!*************************************!*\
  !*** ./src/app/carta/carta.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartaPage": () => (/* binding */ CartaPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _carta_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./carta.page.html?ngResource */ 7823);
/* harmony import */ var _carta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./carta.page.scss?ngResource */ 6698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service.service */ 9353);






let CartaPage = class CartaPage {
    constructor(router, api) {
        this.router = router;
        this.api = api;
        this.results = [];
        this.order = [];
        this.visible = true;
        this.imagesUrl = "http://74.208.181.113:3000/images/";
    }
    ngOnInit() {
        const ida = localStorage.getItem('idproduct');
        this.products = JSON.parse(ida);
        let id = this.products;
        this.api.productList(id).subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
            this.results = responseLocal.recordset;
            console.log(this.results);
        });
    }
    Home() {
        localStorage.removeItem('idproduct');
        this.router.navigate(['/home']);
    }
    map() {
        this.router.navigate(['/map']);
    }
    goToCart() {
        this.generateOrder();
        this.router.navigate(['/cart']);
    }
    addProduct(pid) {
        pid.quantity += 1;
    }
    generateOrder() {
        for (let result of this.results) {
            if (result.quantity > 0) {
                this.order.push(result);
            }
        }
        localStorage.setItem('order', JSON.stringify(this.order));
    }
    removeProduct(pid) {
        if (pid.quantity == 1) {
            pid.quantity -= 1;
            this.visible = false;
        }
        else if (pid.quantity > 0) {
            pid.quantity -= 1;
        }
        else {
            this.visible = false;
        }
    }
};
CartaPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _service_service__WEBPACK_IMPORTED_MODULE_2__.ApiService }
];
CartaPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-carta',
        template: _carta_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_carta_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CartaPage);



/***/ }),

/***/ 6698:
/*!**************************************************!*\
  !*** ./src/app/carta/carta.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = ".header-restaurante {\n  height: 20em;\n  width: 100% !important;\n  background-size: cover;\n  background-repeat: no-repeat;\n  background-position: center center;\n  border-radius: 0 0 2em 2em;\n  box-shadow: 0em 0.2em 0.6em var(--ion-color-medium);\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n.header-restaurante .info-restaurante {\n  text-align: center;\n}\n.header-restaurante .info-restaurante h1, .header-restaurante .info-restaurante h2, .header-restaurante .info-restaurante h3, .header-restaurante .info-restaurante h4 {\n  color: var(--ion-color-light);\n  margin: 0;\n}\n.header-restaurante .info-restaurante h1 {\n  font-size: 4vh;\n}\n.header-restaurante .info-restaurante .nombre-restaurante {\n  padding-top: 1em;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 2em;\n}\n.header-restaurante .info-restaurante .nombre-restaurante ion-icon {\n  margin: 0;\n  padding: 0;\n  margin-left: 0.2em;\n}\n.header-restaurante .info-restaurante .descripcion-restaurante .flex {\n  display: flex;\n  gap: 1em;\n  justify-content: center;\n  align-items: center;\n}\nion-toolbar.busqueda-carta {\n  padding-top: 1em;\n}\n.carta ion-card {\n  box-shadow: none !important;\n}\n.carta ion-card ion-card-title h3 {\n  font-size: 2.6vh;\n}\n.carta ion-card ion-card-subtitle h3 {\n  font-size: 2.2vh;\n}\n.carta ion-card p {\n  font-size: 1.8vh;\n}\n.carta h2 {\n  padding: 1em 0 1em 0;\n}\n.carta .platillo {\n  padding-bottom: 1em;\n  border-bottom: 1px solid var(--ion-color-light);\n}\n.carta .platillo img {\n  object-fit: cover;\n  height: 100%;\n  width: 100%;\n  border-radius: 2em;\n}\n.carta .platillo h3 {\n  font-size: 1.8em;\n  margin: 0;\n}\n.carta .platillo p {\n  margin: 0;\n}\n.add-product {\n  width: 50%;\n  margin: 0 auto;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.add-product ion-icon {\n  color: var(--ion-color-primary);\n}\n.quantity {\n  font-size: 0.8em !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnRhLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxzQkFBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQ0FBQTtFQUNBLDBCQUFBO0VBQ0EsbURBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQ0o7QUFBSTtFQUNJLGtCQUFBO0FBRVI7QUFEUTtFQUNJLDZCQUFBO0VBQ0EsU0FBQTtBQUdaO0FBRFE7RUFDSSxjQUFBO0FBR1o7QUFEUTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxRQUFBO0FBR1o7QUFGWTtFQUNJLFNBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7QUFJaEI7QUFBWTtFQUNJLGFBQUE7RUFDQSxRQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUVoQjtBQUdBO0VBQ0ksZ0JBQUE7QUFBSjtBQUdJO0VBQ0ksMkJBQUE7QUFBUjtBQUVZO0VBQ0ksZ0JBQUE7QUFBaEI7QUFJWTtFQUNJLGdCQUFBO0FBRmhCO0FBS1E7RUFDSSxnQkFBQTtBQUhaO0FBTUk7RUFDSSxvQkFBQTtBQUpSO0FBTUk7RUFDSSxtQkFBQTtFQUNBLCtDQUFBO0FBSlI7QUFLUTtFQUNJLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQUhaO0FBS1E7RUFDSSxnQkFBQTtFQUNBLFNBQUE7QUFIWjtBQUtRO0VBQ0ksU0FBQTtBQUhaO0FBUUE7RUFDSSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBTEo7QUFPSTtFQUNJLCtCQUFBO0FBTFI7QUFRQTtFQUNJLDJCQUFBO0FBTEoiLCJmaWxlIjoiY2FydGEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlci1yZXN0YXVyYW50ZSB7XHJcbiAgICBoZWlnaHQ6IDIwZW07XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAwIDJlbSAyZW07XHJcbiAgICBib3gtc2hhZG93OiAwZW0gMC4yZW0gMC42ZW0gdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIC5pbmZvLXJlc3RhdXJhbnRlIHtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgaDEsaDIsaDMsaDQge1xyXG4gICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBoMSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogNHZoO1xyXG4gICAgICAgIH1cclxuICAgICAgICAubm9tYnJlLXJlc3RhdXJhbnRlIHtcclxuICAgICAgICAgICAgcGFkZGluZy10b3A6IDFlbTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGdhcDogMmVtO1xyXG4gICAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDAuMmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5kZXNjcmlwY2lvbi1yZXN0YXVyYW50ZSB7XHJcbiAgICAgICAgICAgIC5mbGV4IHtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgICAgICBnYXA6IDFlbTtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5pb24tdG9vbGJhci5idXNxdWVkYS1jYXJ0YSB7XHJcbiAgICBwYWRkaW5nLXRvcDogMWVtO1xyXG59XHJcbi5jYXJ0YSB7XHJcbiAgICBpb24tY2FyZCB7XHJcbiAgICAgICAgYm94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGlvbi1jYXJkLXRpdGxlIHtcclxuICAgICAgICAgICAgaDMge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyLjZ2aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBpb24tY2FyZC1zdWJ0aXRsZSB7XHJcbiAgICAgICAgICAgIGgzIHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMi4ydmg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMS44dmg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgaDIge1xyXG4gICAgICAgIHBhZGRpbmc6IDFlbSAwIDFlbSAwO1xyXG4gICAgfVxyXG4gICAgLnBsYXRpbGxvIHtcclxuICAgICAgICBwYWRkaW5nLWJvdHRvbTogMWVtO1xyXG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyZW07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGgzIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxLjhlbTtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICBwIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmFkZC1wcm9kdWN0IHtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIH1cclxufVxyXG4ucXVhbnRpdHkge1xyXG4gICAgZm9udC1zaXplOiAwLjhlbSAhaW1wb3J0YW50O1xyXG59Il19 */";

/***/ }),

/***/ 7823:
/*!**************************************************!*\
  !*** ./src/app/carta/carta.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"close\" id=\"flechita-atras\" (click)=\"Home()\"></ion-icon>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n<div class=\"contenedor\">\r\n\r\n  <div class=\"header-restaurante\" style=\"background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),url('{{imagesUrl}}{{key}}{{products.img}}');\">\r\n\r\n    <div class=\"info-restaurante\">\r\n\r\n      <div class=\"nombre-restaurante\"> \r\n        <h1>{{products.nameRestaurant}}</h1>\r\n      </div>\r\n\r\n      <div class=\"descripcion-restaurante\">\r\n        <div class=\"flex\">\r\n          <h3>{{products.rType}}</h3>\r\n          <h3> 4.3<ion-icon name=\"star\"></ion-icon> </h3>\r\n        </div>  \r\n        <h3 style=\"border-bottom: 1px solid var(--ion-color-light); cursor:pointer;\" (click)=\"map()\"> {{products.address}}</h3>\r\n      </div>\r\n\r\n    </div>\r\n    \r\n  </div>\r\n\r\n  <h1 class=\"title\">Menu</h1>\r\n  <ion-searchbar placeholder=\"What do you want to eat?\" color=\"light\"></ion-searchbar>\r\n\r\n  <div class=\"carta\" *ngFor=\"let item of results\">\r\n\r\n    <h2>{{item.productType}}</h2>\r\n\r\n    <ion-card class=\"platillo\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size-lg=\"10\" size-md=\"8\" size-xs=\"7\">\r\n            <div class=\"platillo-info\">\r\n              <ion-card-title> <h3>{{item.nameProduct}} </h3> </ion-card-title>\r\n              <ion-card-subtitle> <h3>{{item.price}} MXN</h3> </ion-card-subtitle>\r\n              <p class=\"description\">{{item.descriptionProduct}}</p>\r\n                <h3 class=\"add-product\">\r\n                  <ion-icon name=\"remove-circle-outline\" size=\"large\" id=\"remove\" (click)=\"removeProduct(item)\"></ion-icon>\r\n                  <p class=\"quantity\">{{item.quantity}}</p>\r\n                  <ion-icon name=\"add-circle-outline\" size=\"large\" id=\"add\" (click)=\"addProduct(item)\"></ion-icon>\r\n                </h3>\r\n            </div>\r\n          </ion-col>\r\n          <ion-col size-lg=\"2\" size-md=\"4\" size-xs=\"5\" class=\"right-side-product\">\r\n            <ion-row class=\"product-image\">\r\n              <img src=\"{{imagesUrl}}{{item.imgP}}\" alt=\"Imagen del platillo\" (click)=\"visible=true\">\r\n            </ion-row>\r\n          </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n    </ion-card>\r\n\r\n  </div>\r\n\r\n</div>\r\n</ion-content>\r\n\r\n<ion-footer class=\"footer\">\r\n  <ion-button expand=\"round\" color=\"secondary\" (click)=\"goToCart()\">Cart</ion-button>\r\n</ion-footer>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_carta_carta_module_ts.js.map