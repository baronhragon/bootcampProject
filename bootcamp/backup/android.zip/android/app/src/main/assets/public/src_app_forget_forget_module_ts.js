"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_forget_forget_module_ts"],{

/***/ 386:
/*!*************************************************!*\
  !*** ./src/app/forget/forget-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPageRoutingModule": () => (/* binding */ ForgetPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _forget_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget.page */ 8946);




const routes = [
    {
        path: '',
        component: _forget_page__WEBPACK_IMPORTED_MODULE_0__.ForgetPage
    }
];
let ForgetPageRoutingModule = class ForgetPageRoutingModule {
};
ForgetPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ForgetPageRoutingModule);



/***/ }),

/***/ 9296:
/*!*****************************************!*\
  !*** ./src/app/forget/forget.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPageModule": () => (/* binding */ ForgetPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _forget_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget-routing.module */ 386);
/* harmony import */ var _forget_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget.page */ 8946);







let ForgetPageModule = class ForgetPageModule {
};
ForgetPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _forget_routing_module__WEBPACK_IMPORTED_MODULE_0__.ForgetPageRoutingModule
        ],
        declarations: [_forget_page__WEBPACK_IMPORTED_MODULE_1__.ForgetPage]
    })
], ForgetPageModule);



/***/ }),

/***/ 8946:
/*!***************************************!*\
  !*** ./src/app/forget/forget.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ForgetPage": () => (/* binding */ ForgetPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _forget_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./forget.page.html?ngResource */ 9113);
/* harmony import */ var _forget_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget.page.scss?ngResource */ 7352);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _map_map_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../map/map.module */ 2622);





let ForgetPage = class ForgetPage {
    constructor(mod) {
        this.mod = mod;
    }
    ngOnInit() {
    }
};
ForgetPage.ctorParameters = () => [
    { type: _map_map_module__WEBPACK_IMPORTED_MODULE_2__.MapPageModule }
];
ForgetPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-forget',
        template: _forget_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_forget_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ForgetPage);



/***/ }),

/***/ 7352:
/*!****************************************************!*\
  !*** ./src/app/forget/forget.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmb3JnZXQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 9113:
/*!****************************************************!*\
  !*** ./src/app/forget/forget.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>forget</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <app-map</app-map>\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_forget_forget_module_ts.js.map