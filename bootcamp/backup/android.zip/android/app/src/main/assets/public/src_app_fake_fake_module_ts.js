"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_fake_fake_module_ts"],{

/***/ 476:
/*!*********************************************!*\
  !*** ./src/app/fake/fake-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FakePageRoutingModule": () => (/* binding */ FakePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _fake_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fake.page */ 2480);




const routes = [
    {
        path: '',
        component: _fake_page__WEBPACK_IMPORTED_MODULE_0__.FakePage
    }
];
let FakePageRoutingModule = class FakePageRoutingModule {
};
FakePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FakePageRoutingModule);



/***/ }),

/***/ 8719:
/*!*************************************!*\
  !*** ./src/app/fake/fake.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FakePageModule": () => (/* binding */ FakePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _fake_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fake-routing.module */ 476);
/* harmony import */ var _fake_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fake.page */ 2480);







let FakePageModule = class FakePageModule {
};
FakePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _fake_routing_module__WEBPACK_IMPORTED_MODULE_0__.FakePageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_fake_page__WEBPACK_IMPORTED_MODULE_1__.FakePage]
    })
], FakePageModule);



/***/ }),

/***/ 2480:
/*!***********************************!*\
  !*** ./src/app/fake/fake.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FakePage": () => (/* binding */ FakePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _fake_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fake.page.html?ngResource */ 9051);
/* harmony import */ var _fake_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fake.page.scss?ngResource */ 5026);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service.service */ 9353);






let FakePage = class FakePage {
    constructor(api, formBuilder) {
        this.api = api;
        this.formBuilder = formBuilder;
        this.results = [];
        this.option = {
            slidesPerView: 4,
            centeredSlides: true,
            loop: true,
            spaceBetween: 10,
        };
        this.registerForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
        });
    }
    ngOnInit() {
    }
    getAllUsers() {
        this.api.pruebaGet().subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
            this.results = responseLocal.recordset;
        });
    }
    register() {
        let data = {
            nombre: this.registerForm.value.nombre,
            address: this.registerForm.value.address,
        };
        this.api.pruebaPost(data).subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
        });
    }
};
FakePage.ctorParameters = () => [
    { type: _service_service__WEBPACK_IMPORTED_MODULE_2__.ApiService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder }
];
FakePage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-fake',
        template: _fake_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_fake_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FakePage);



/***/ }),

/***/ 5026:
/*!************************************************!*\
  !*** ./src/app/fake/fake.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-card {\n  width: 100%;\n  height: 200px;\n  box-shadow: inset;\n  border-radius: 12px;\n}\nion-card img {\n  object-fit: cover;\n  height: 100px;\n  width: 100%;\n  transition: 600ms all ease-in-out;\n}\n.swiper-slide {\n  transition: 400ms all ease-in-out;\n}\n#header {\n  display: flex;\n  align-items: center;\n  justify-content: space-around;\n  padding: 2%;\n}\nion-icon {\n  font-size: 30px;\n  padding: 10px;\n}\n#avatars {\n  height: 200px;\n  object-fit: cover;\n  width: 100%;\n  transition: 600ms all ease-in-out;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZha2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FBQ0o7QUFDSTtFQUNFLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxpQ0FBQTtBQUNOO0FBR0U7RUFDRSxpQ0FBQTtBQUFKO0FBR0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7QUFBSjtBQUdFO0VBQ0UsZUFBQTtFQUNBLGFBQUE7QUFBSjtBQUdFO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGlDQUFBO0FBQUoiLCJmaWxlIjoiZmFrZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMjAwcHg7XHJcbiAgICBib3gtc2hhZG93OiBpbnNldDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEycHg7XHJcbiAgXHJcbiAgICBpbWcge1xyXG4gICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIHRyYW5zaXRpb246IDYwMG1zIGFsbCBlYXNlLWluLW91dDtcclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLnN3aXBlci1zbGlkZSB7XHJcbiAgICB0cmFuc2l0aW9uOiA0MDBtcyBhbGwgZWFzZS1pbi1vdXQ7XHJcbiAgfVxyXG4gIFxyXG4gICNoZWFkZXIge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcclxuICAgIHBhZGRpbmc6IDIlO1xyXG4gIH1cclxuICBcclxuICBpb24taWNvbiB7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gIH1cclxuICBcclxuICAjYXZhdGFycyB7XHJcbiAgICBoZWlnaHQ6IDIwMHB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRyYW5zaXRpb246IDYwMG1zIGFsbCBlYXNlLWluLW91dDtcclxuICB9Il19 */";

/***/ }),

/***/ 9051:
/*!************************************************!*\
  !*** ./src/app/fake/fake.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>fake</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content [fullscreen]=\"true\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"12\"\r\n        ><ion-label>\r\n          <h1>Favorite</h1>\r\n          <ion-slides [options]=\"option\">\r\n            <ion-slide *ngFor=\"let user of results\">\r\n              <ion-card>\r\n                <ion-card-title>{{user.nombre}}</ion-card-title>\r\n                <ion-card-subtitle>{{user.address}}</ion-card-subtitle>\r\n                <h3>{{user.email}}</h3>\r\n                <p>{{user.phone}}</p>\r\n              </ion-card>\r\n            </ion-slide>\r\n          </ion-slides>\r\n        </ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <form [formGroup]=\"registerForm\" (ngSubmit)=\"register()\" >\r\n    <ion-item>\r\n      <ion-label> Full name </ion-label>\r\n      <ion-input  formControlName=\"nombre\"></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item>\r\n      <ion-label> Address </ion-label>\r\n      <ion-input formControlName=\"address\"></ion-input>\r\n    </ion-item>\r\n    <ion-button type=\"submit\" (click)=\"register()\" expand=\"block\" fill=\"clear\" shape=\"round\">\r\n      submit\r\n    </ion-button>\r\n  </form>\r\n\r\n<ion-button (click)=\"getAllUsers()\" expand=\"block\" shape=\"round\">\r\n  Click me\r\n</ion-button>\r\n</ion-content>\r\n\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_fake_fake_module_ts.js.map