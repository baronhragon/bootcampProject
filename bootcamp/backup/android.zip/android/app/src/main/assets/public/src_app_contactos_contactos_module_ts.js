"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_contactos_contactos_module_ts"],{

/***/ 875:
/*!*******************************************************!*\
  !*** ./src/app/contactos/contactos-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPageRoutingModule": () => (/* binding */ ContactosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _contactos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos.page */ 4042);




const routes = [
    {
        path: '',
        component: _contactos_page__WEBPACK_IMPORTED_MODULE_0__.ContactosPage
    }
];
let ContactosPageRoutingModule = class ContactosPageRoutingModule {
};
ContactosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ContactosPageRoutingModule);



/***/ }),

/***/ 3570:
/*!***********************************************!*\
  !*** ./src/app/contactos/contactos.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPageModule": () => (/* binding */ ContactosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _contactos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos-routing.module */ 875);
/* harmony import */ var _contactos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contactos.page */ 4042);







let ContactosPageModule = class ContactosPageModule {
};
ContactosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _contactos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ContactosPageRoutingModule
        ],
        declarations: [_contactos_page__WEBPACK_IMPORTED_MODULE_1__.ContactosPage]
    })
], ContactosPageModule);



/***/ }),

/***/ 4042:
/*!*********************************************!*\
  !*** ./src/app/contactos/contactos.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPage": () => (/* binding */ ContactosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _contactos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos.page.html?ngResource */ 8348);
/* harmony import */ var _contactos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contactos.page.scss?ngResource */ 9663);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let ContactosPage = class ContactosPage {
    constructor() {
        this.room = [];
        this.contacts = [];
        this.results = [];
        this.finished = false;
    }
    ngOnInit() {
        this.results = JSON.parse(sessionStorage.getItem('existing'));
        this.contacts = JSON.parse(sessionStorage.getItem('phoneContacts'));
        console.log(this.results);
        console.log(this.contacts);
    }
    saveContacts(i) {
        console.log('Nuevo estado:' + JSON.stringify(i));
        if (i.check === false) {
            this.room.push(i);
        }
        else {
            let index = this.room.indexOf(i);
            this.room.splice(index, 1);
        }
        console.log(this.room);
    }
};
ContactosPage.ctorParameters = () => [];
ContactosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-contactos',
        template: _contactos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_contactos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
    // export interface PhoneContact {
    //   contactId: string;
    //   lookupKey: string;
    //   displayName: string;
    //   phoneNumbers: [string];
    //   emails: [string];
    // }
], ContactosPage);



/***/ }),

/***/ 9663:
/*!**********************************************************!*\
  !*** ./src/app/contactos/contactos.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhY3Rvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUVBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxRQUFBO0VBQ0EsMkJBQUE7QUFBSjs7QUFHRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUdFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBRUEsY0FBQTtFQUVBLFNBQUE7QUFGSjs7QUFLRTtFQUNFLHFCQUFBO0FBRkoiLCJmaWxlIjoiY29udGFjdG9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNjb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIFxyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XHJcbiAgfVxyXG4gIFxyXG4gICNjb250YWluZXIgc3Ryb25nIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xyXG4gIH1cclxuICBcclxuICAjY29udGFpbmVyIHAge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgXHJcbiAgICBjb2xvcjogIzhjOGM4YztcclxuICBcclxuICAgIG1hcmdpbjogMDtcclxuICB9XHJcbiAgXHJcbiAgI2NvbnRhaW5lciBhIHtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICB9Il19 */";

/***/ }),

/***/ 8348:
/*!**********************************************************!*\
  !*** ./src/app/contactos/contactos.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"arrow-back-outline\" id=\"flechita-atras\" (click)=\"Home()\"></ion-icon>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content fullscreen>\r\n<div class=\"contenedor\">\r\n\r\n  <h1 class=\"title\">Select your guests</h1>\r\n  <p class=\"description\">Select the guests for your reservation</p>\r\n\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of results\">\r\n      <ion-avatar *ngIf=\"item.img\"  slot=\"start\">\r\n        <img src=\"{{item.img}} || ../../../../assets/default-avatar.png\" [hidden]=\"lastImage === null\">\r\n      </ion-avatar>\r\n      <ion-text color=\"dark\">\r\n        <h3>{{item.nombre}}</h3>\r\n      </ion-text>\r\n      <!-- <ion-checkbox color=\"secondary\" [(ngModel)]=\"item.check\" checked=\"false\" (click)=\"saveContacts(item)\" slot=\"end\" ></ion-checkbox> -->\r\n      <ion-checkbox color=\"secondary\" checked=\"false\" (click)=\"saveContacts(item)\" slot=\"end\" ></ion-checkbox>\r\n    </ion-item>\r\n</ion-list>\r\n\r\n<ion-list>\r\n\r\n  <ion-item *ngFor=\"let contact of contacts\" >\r\n    <ion-icon *ngIf=\"!contact.photoThumbnail\" color=\"primary\" slot=\"start\" name=\"person-circle\"></ion-icon>\r\n    <ion-avatar *ngIf=\"contact.photoThumbnail\"  slot=\"start\">\r\n      <ion-img [src]=\"contact.photoThumbnail\"></ion-img>\r\n    </ion-avatar>\r\n    <ion-label class=\"ion-text-wrap\">\r\n      <ion-text color=\"dark\">\r\n        <h3>{{contact.user}}</h3>\r\n      </ion-text>\r\n      <ion-text color=\"medium\">\r\n        <p>{{contact.phone}}</p>\r\n      </ion-text>\r\n    </ion-label>\r\n    <ion-button (click)=\"onClick()\" expand=\"block\" fill=\"clear\" shape=\"round\">\r\n      Invite\r\n    </ion-button>\r\n  </ion-item>\r\n\r\n  \r\n</ion-list>\r\n\r\n</div>\r\n</ion-content>\r\n\r\n<ion-footer class=\"footer\">\r\n  <ion-button shape=\"round\" color=\"secondary\" (click)=\"SeleccionarRestaurante()\" >Accept</ion-button>\r\n</ion-footer>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_contactos_contactos_module_ts.js.map