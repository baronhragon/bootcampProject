"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_register_register_module_ts"],{

/***/ 3963:
/*!*****************************************************!*\
  !*** ./src/app/register/register-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 8135);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 8723:
/*!*********************************************!*\
  !*** ./src/app/register/register.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 3963);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 8135);







let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 8135:
/*!*******************************************!*\
  !*** ./src/app/register/register.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.html?ngResource */ 4754);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 6219);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _capacitor_device__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/device */ 4744);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../service.service */ 9353);









let RegisterPage = class RegisterPage {
  constructor(fb, alertController, navCtrl, api) {
    this.fb = fb;
    this.alertController = alertController;
    this.navCtrl = navCtrl;
    this.api = api;
    this.formularioRegistro = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required),
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.email),
      phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required),
      confirmacionPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required)
    });
  }

  guardar() {
    var _this = this;

    return (0,C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let f = _this.formularioRegistro.value;
      let user = {
        nombre: f.nombre,
        password: f.password,
        address: f.address,
        email: f.email,
        phone: f.phone,
        confirmacionPassword: f.confirmacionPassword,
        phoneId: yield _this.logDeviceId()
      };
      console.log(user);

      if (f.password === f.confirmacionPassword) {
        _this.passwordError = true;
        console.log(_this.passwordError);

        _this.api.userPostRegister(user).subscribe(responseFromTheServer => {
          console.log(user);
          let responseLocal;
          responseLocal = responseFromTheServer;
        });

        _this.navCtrl.navigateRoot('login');
      } else {
        _this.passwordError = false;
        console.log(_this.passwordError);
      }
    })();
  }

  ngOnInit() {
    this.formularioRegistro = new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormGroup({
      nombre: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.email]),
      phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]),
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required]),
      confirmacionPassword: new _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_5__.Validators.required])
    });
  }

  goBack() {
    this.navCtrl.navigateRoot('first-page');
  }

  newAuth() {
    this.navCtrl.navigateRoot('inicio');
  }

  logDeviceId() {
    return (0,C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let id = yield _capacitor_device__WEBPACK_IMPORTED_MODULE_3__.Device.getId();
      let uuid = id.uuid;
      return uuid;
    })();
  }

};

RegisterPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
}, {
  type: _service_service__WEBPACK_IMPORTED_MODULE_4__.ApiService
}];

RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-register',
  template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], RegisterPage);


/***/ }),

/***/ 4758:
/*!****************************************************************!*\
  !*** ./node_modules/@capacitor/device/dist/esm/definitions.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 4744:
/*!**********************************************************!*\
  !*** ./node_modules/@capacitor/device/dist/esm/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Device": () => (/* binding */ Device)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 6549);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 4758);

const Device = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Device', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_device_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 5168)).then(m => new m.DeviceWeb())
});



/***/ }),

/***/ 6219:
/*!********************************************************!*\
  !*** ./src/app/register/register.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "h1 {\n  text-align: center;\n}\n\nion-item ion-input {\n  border: 1px solid var(--ion-color-medium);\n  --padding-start: 2vh;\n  border-radius: 2vh;\n  height: 4vh;\n}\n\nion-item ion-input[type=text] {\n  --padding-left: 2vh;\n}\n\nion-item ion-label {\n  display: flex;\n  align-items: center;\n  font-size: 1.8vh;\n  color: var(--ion-color-medium);\n  padding: 0 2vh;\n  font-family: \"Hind\", sans-serif;\n  height: 2vh;\n}\n\nion-item ion-icon {\n  padding-right: 2vh;\n}\n\n.formulario-registro {\n  margin-bottom: 2vh;\n}\n\n#buttom {\n  height: 5vh;\n  font-size: 1.8vh;\n  display: flex;\n  justify-content: center;\n  width: 90%;\n  margin: 6vh auto 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUU7RUFDRSx5Q0FBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBQ0o7O0FBQ0U7RUFDRSxtQkFBQTtBQUNKOztBQUNFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSw4QkFBQTtFQUNBLGNBQUE7RUFDQSwrQkFBQTtFQUNBLFdBQUE7QUFDSjs7QUFDRTtFQUNFLGtCQUFBO0FBQ0o7O0FBRUE7RUFDRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0ksV0FBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtFQUNBLHVCQUFBO0FBQ0oiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaDEge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbmlvbi1pdGVtIHtcclxuICBpb24taW5wdXQge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDJ2aDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDJ2aDtcclxuICAgIGhlaWdodDogNHZoO1xyXG4gIH1cclxuICBpb24taW5wdXRbdHlwZT10ZXh0XSB7XHJcbiAgICAtLXBhZGRpbmctbGVmdDogMnZoO1xyXG4gIH1cclxuICBpb24tbGFiZWwge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDEuOHZoO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgcGFkZGluZzogMCAydmg7XHJcbiAgICBmb250LWZhbWlseTogJ0hpbmQnLCBzYW5zLXNlcmlmO1xyXG4gICAgaGVpZ2h0OiAydmg7XHJcbiAgfVxyXG4gIGlvbi1pY29uIHtcclxuICAgIHBhZGRpbmctcmlnaHQ6IDJ2aDtcclxuICB9XHJcbn1cclxuLmZvcm11bGFyaW8tcmVnaXN0cm8ge1xyXG4gIG1hcmdpbi1ib3R0b206IDJ2aDtcclxufVxyXG5cclxuI2J1dHRvbSB7XHJcbiAgICBoZWlnaHQ6IDV2aDtcclxuICAgIGZvbnQtc2l6ZTogMS44dmg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgbWFyZ2luOiA2dmggYXV0byAwIGF1dG87XHJcbn0iXX0= */";

/***/ }),

/***/ 4754:
/*!********************************************************!*\
  !*** ./src/app/register/register.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"arrow-back-outline\" id=\"flechita-atras\" (click)=\"goBack()\"></ion-icon>\r\n  </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div class=\"contenedor\">\r\n    \r\n    <h1 class=\"title\">Let's get started!</h1>\r\n\r\n    <form class=\"formulario-registro\" [formGroup]=\"formularioRegistro\" (keyup.enter)=\"guardar()\">\r\n      \r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\"> Full name </ion-label>\r\n        <ion-input formControlName=\"nombre\"></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\"> Phone </ion-label>\r\n        <ion-input formControlName=\"phone\"></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\"> Email </ion-label>\r\n        <ion-input formControlName=\"email\" ng-pattern=\" ^[a-z]+[a-z0-9._-]+@[a-z]+\\.[a-z.]{2,5}$\" ></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Password</ion-label>\r\n        <ion-input required formControlName=\"password\" type=\"password\"></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-label position=\"floating\">Confirm password</ion-label>\r\n        <ion-input required formControlName=\"confirmacionPassword\" type=\"password\"></ion-input>\r\n      </ion-item>\r\n    </form>\r\n\r\n    <ion-item class=\"errormsg\" lines=\"none\">\r\n      <div class=\"error\" \r\n      *ngIf=\r\n      \"formularioRegistro.get('nombre').hasError('required') &&\r\n      formularioRegistro.get('phone').hasError('required') &&\r\n      formularioRegistro.get('email').hasError('required') &&\r\n      formularioRegistro.get('password').hasError('required') &&\r\n      formularioRegistro.get('confirmacionPassword').hasError('required')\">\r\n      <ion-icon name=\"warning-outline\"></ion-icon>All fields are required\r\n      </div>\r\n    </ion-item>\r\n\r\n    <ion-button id=\"buttom\" color=\"secondary\" (click)=\"guardar()\" expand=\"block\" shape=\"round\" (click)=\"logDeviceId()\">Sign Up</ion-button>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_register_register_module_ts.js.map