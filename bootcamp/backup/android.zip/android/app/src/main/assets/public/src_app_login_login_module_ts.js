"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_login_login_module_ts"],{

/***/ 5393:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 6825);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 107:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 5393);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 6825);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 6825:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.html?ngResource */ 1729);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 7047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../service.service */ 9353);








let LoginPage = class LoginPage {
  constructor(fb, alertController, navCtrl, api) {
    this.fb = fb;
    this.alertController = alertController;
    this.navCtrl = navCtrl;
    this.api = api;
    this.errorUser = false;
    this.formularioLogin = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroup({
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl(),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl()
    });
  }

  ngOnInit() {
    this.formularioLogin = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormGroup({
      email: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required, _angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.email]),
      password: new _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormControl('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__.Validators.required])
    });
  }

  ingresar() {
    var _this = this;

    return (0,C_Users_arame_bootcamp_proyectoBootcamp_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let f = _this.formularioLogin.value;
      let user = {
        email: f.email,
        password: f.password
      };

      _this.api.userPostLogin(user).subscribe(responseFromTheServer => {
        let responseLocal;
        responseLocal = responseFromTheServer;

        if (responseLocal.recordset.length > 0) {
          window.localStorage.setItem("idUser", JSON.stringify(responseLocal.recordset));

          _this.navCtrl.navigateRoot('home');

          return;
        } else {
          console.log("incorrecto");
        }
      });
    })();
  }

  goBack() {
    this.navCtrl.navigateRoot('first-page');
  }

  signUp() {
    this.navCtrl.navigateRoot('register');
  }

  forget() {
    this.navCtrl.navigateRoot('forget');
  }

};

LoginPage.ctorParameters = () => [{
  type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormBuilder
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.NavController
}, {
  type: _service_service__WEBPACK_IMPORTED_MODULE_3__.ApiService
}];

LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-login',
  template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], LoginPage);


/***/ }),

/***/ 7047:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = ".hero {\n  background-image: url('login1.png');\n  background-size: cover;\n  background-position: center center;\n  width: 100%;\n  height: 30%;\n}\n\nh1 {\n  padding-top: 4vh;\n  text-align: center;\n}\n\n.formularioLogin {\n  width: 95%;\n  margin: 0 auto;\n}\n\nion-item ion-input {\n  border: 1px solid var(--ion-color-medium);\n  --padding-start: 2vh;\n  border-radius: 2vh;\n  height: 4vh;\n}\n\nion-item ion-input[type=text] {\n  --padding-left: 2vh;\n}\n\nion-item ion-label {\n  display: flex;\n  align-items: center;\n  font-size: 1.8vh;\n  color: var(--ion-color-medium);\n  padding: 0 2vh;\n  font-family: \"Hind\", sans-serif;\n  height: 2vh;\n}\n\nion-item ion-icon {\n  padding-right: 2vh;\n}\n\n.opciones-secundarias {\n  display: flex;\n  justify-content: space-between;\n  width: 80%;\n  margin: 0 auto;\n  padding-top: 2vh;\n}\n\n.opciones-secundarias button {\n  background-color: transparent;\n}\n\n#buttom {\n  height: 5vh;\n  font-size: 1.8vh;\n  display: flex;\n  justify-content: center;\n  width: 90%;\n  margin: 6vh auto 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG1DQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQ0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBRUY7O0FBQ0E7RUFDRSxVQUFBO0VBQ0EsY0FBQTtBQUVGOztBQUNFO0VBQ0UseUNBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUVKOztBQUFFO0VBQ0UsbUJBQUE7QUFFSjs7QUFBRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0EsK0JBQUE7RUFDQSxXQUFBO0FBRUo7O0FBQUU7RUFDRSxrQkFBQTtBQUVKOztBQUVBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUFFO0VBQ0UsNkJBQUE7QUFFSjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtBQUNGIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZXJve1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6dXJsKFwiLi4vLi4vYXNzZXRzL3JlY3Vyc29zL2xvZ2luMS5wbmdcIik7XHJcbiAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMzAlO1xyXG59XHJcbmgxIHtcclxuICBwYWRkaW5nLXRvcDogNHZoO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLmZvcm11bGFyaW9Mb2dpbiB7XHJcbiAgd2lkdGg6IDk1JTtcclxuICBtYXJnaW46IDAgYXV0bztcclxufVxyXG5pb24taXRlbSB7XHJcbiAgaW9uLWlucHV0IHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAydmg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAydmg7XHJcbiAgICBoZWlnaHQ6IDR2aDtcclxuICB9XHJcbiAgaW9uLWlucHV0W3R5cGU9dGV4dF0ge1xyXG4gICAgLS1wYWRkaW5nLWxlZnQ6IDJ2aDtcclxuICB9XHJcbiAgaW9uLWxhYmVsIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxLjh2aDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgIHBhZGRpbmc6IDAgMnZoO1xyXG4gICAgZm9udC1mYW1pbHk6ICdIaW5kJywgc2Fucy1zZXJpZjtcclxuICAgIGhlaWdodDogMnZoO1xyXG4gIH1cclxuICBpb24taWNvbiB7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAydmg7XHJcbiAgfVxyXG59XHJcblxyXG4ub3BjaW9uZXMtc2VjdW5kYXJpYXMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIHdpZHRoOiA4MCU7XHJcbiAgbWFyZ2luOiAwIGF1dG87XHJcbiAgcGFkZGluZy10b3A6IDJ2aDtcclxuICBidXR0b24ge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7ICBcclxuICB9XHJcbn1cclxuXHJcbiNidXR0b20ge1xyXG4gIGhlaWdodDogNXZoO1xyXG4gIGZvbnQtc2l6ZTogMS44dmg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB3aWR0aDogOTAlO1xyXG4gIG1hcmdpbjogNnZoIGF1dG8gMCBhdXRvO1xyXG59XHJcblxyXG5cclxuIl19 */";

/***/ }),

/***/ 1729:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-icon name=\"arrow-back-outline\" id=\"flechita-atras\" (click)=\"goBack()\"></ion-icon>\r\n  </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  <div class=\"hero\"></div>\r\n  \r\n  <div class=\"contenedor\">\r\n    <h1 class=\"title\">Welcome back!</h1>\r\n\r\n    <form class=\"formularioLogin\" [formGroup]=\"formularioLogin\" (ngSubmit)=\"ingresar()\">\r\n        \r\n      <ion-item class=\"input\" lines=\"none\">\r\n          <ion-label position=\"floating\">Email Address</ion-label>\r\n          <ion-input\r\n            formControlName=\"email\"\r\n            name=\"email\"\r\n            required\r\n            inputmode=\"text\"\r\n            type=\"text\">\r\n          </ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item class=\"input\" lines=\"none\">\r\n          <ion-label position=\"floating\">Password</ion-label>\r\n          <ion-input\r\n            required\r\n            formControlName=\"password\"\r\n            name=\"password\"\r\n            size=\"password\"\r\n            type=\"password\">\r\n          </ion-input>\r\n        </ion-item>\r\n      </form>\r\n\r\n    <div class=\"opciones-secundarias\">\r\n      <button (click)=\"forget()\"> <h3>Forgot your password?</h3> </button>\r\n      <button (click)=\"signUp()\"> <h3>Sign up</h3> </button>\r\n    </div>\r\n\r\n    <ion-item class=\"errormsg\" lines=\"none\">\r\n      <div class=\"error\" \r\n      *ngIf=\"formularioLogin.get('email').hasError('required') || formularioLogin.get('password').hasError('required')\">\r\n      <ion-icon name=\"warning-outline\"></ion-icon>Both fields are required\r\n      </div>\r\n    </ion-item>\r\n\r\n    <ion-item class=\"errormsg\" lines=\"none\">\r\n      <div class=\"error\" \r\n      *ngIf=\"formularioLogin.get('email').hasError('email')\">\r\n      <ion-icon name=\"warning-outline\"></ion-icon>Invalid email adress\r\n      </div>\r\n    </ion-item>\r\n\r\n    <ion-button id=\"buttom\" color=\"secondary\" (click)=\"ingresar()\" type=\"submit\" expand=\"block\" shape=\"round\">Login</ion-button>\r\n\r\n  </div>\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map