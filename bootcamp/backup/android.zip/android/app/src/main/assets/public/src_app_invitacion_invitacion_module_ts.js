"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_invitacion_invitacion_module_ts"],{

/***/ 2909:
/*!*********************************************************!*\
  !*** ./src/app/invitacion/invitacion-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitacionPageRoutingModule": () => (/* binding */ InvitacionPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _invitacion_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./invitacion.page */ 2093);




const routes = [
    {
        path: '',
        component: _invitacion_page__WEBPACK_IMPORTED_MODULE_0__.InvitacionPage,
    }
];
let InvitacionPageRoutingModule = class InvitacionPageRoutingModule {
};
InvitacionPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], InvitacionPageRoutingModule);



/***/ }),

/***/ 6515:
/*!*************************************************!*\
  !*** ./src/app/invitacion/invitacion.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitacionPageModule": () => (/* binding */ InvitacionPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _invitacion_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./invitacion-routing.module */ 2909);
/* harmony import */ var _invitacion_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitacion.page */ 2093);







let InvitacionPageModule = class InvitacionPageModule {
};
InvitacionPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _invitacion_routing_module__WEBPACK_IMPORTED_MODULE_0__.InvitacionPageRoutingModule
        ],
        declarations: [_invitacion_page__WEBPACK_IMPORTED_MODULE_1__.InvitacionPage]
    })
], InvitacionPageModule);



/***/ }),

/***/ 2093:
/*!***********************************************!*\
  !*** ./src/app/invitacion/invitacion.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvitacionPage": () => (/* binding */ InvitacionPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _invitacion_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./invitacion.page.html?ngResource */ 7484);
/* harmony import */ var _invitacion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./invitacion.page.scss?ngResource */ 2638);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let InvitacionPage = class InvitacionPage {
    constructor(router) {
        this.router = router;
    }
    Aceptar() {
        this.router.navigate(['/aceptar']);
    }
    Rechazar() {
        this.router.navigate(['/rechazar']);
    }
    Home() {
        this.router.navigate(['/home']);
    }
    Carta() {
        this.router.navigate(['/carta']);
    }
};
InvitacionPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
InvitacionPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-home',
        template: _invitacion_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_invitacion_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], InvitacionPage);



/***/ }),

/***/ 2638:
/*!************************************************************!*\
  !*** ./src/app/invitacion/invitacion.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "#botones-invitacion {\n  display: flex;\n  justify-content: center;\n  gap: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImludml0YWNpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsU0FBQTtBQUNGIiwiZmlsZSI6Imludml0YWNpb24ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiI2JvdG9uZXMtaW52aXRhY2lvbiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBnYXA6IDIwcHg7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 7484:
/*!************************************************************!*\
  !*** ./src/app/invitacion/invitacion.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <ion-icon name=\"chevron-back-outline\" id=\"flechita-atras\"></ion-icon>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div id=\"container\">\r\n    <h2>Melany Jiménez te ha invitado a comer</h2>\r\n    <h4>¿Quieres unirte a su sala?</h4>\r\n    <div id=\"botones-invitacion\">\r\n      <ion-button color=\"light\" size=\"large\" (click)=\"Rechazar()\">Rechazar</ion-button>\r\n      <ion-button color=\"primary\" size=\"large\" (click)=\"Aceptar()\">Aceptar</ion-button>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_invitacion_invitacion_module_ts.js.map