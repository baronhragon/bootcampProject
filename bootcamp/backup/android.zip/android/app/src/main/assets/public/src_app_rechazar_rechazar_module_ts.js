"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_rechazar_rechazar_module_ts"],{

/***/ 2797:
/*!*****************************************************!*\
  !*** ./src/app/rechazar/rechazar-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RechazarPageRoutingModule": () => (/* binding */ RechazarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _rechazar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rechazar.page */ 1691);




const routes = [
    {
        path: '',
        component: _rechazar_page__WEBPACK_IMPORTED_MODULE_0__.RechazarPage
    }
];
let RechazarPageRoutingModule = class RechazarPageRoutingModule {
};
RechazarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RechazarPageRoutingModule);



/***/ }),

/***/ 7604:
/*!*********************************************!*\
  !*** ./src/app/rechazar/rechazar.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RechazarPageModule": () => (/* binding */ RechazarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _rechazar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rechazar-routing.module */ 2797);
/* harmony import */ var _rechazar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rechazar.page */ 1691);







let RechazarPageModule = class RechazarPageModule {
};
RechazarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _rechazar_routing_module__WEBPACK_IMPORTED_MODULE_0__.RechazarPageRoutingModule
        ],
        declarations: [_rechazar_page__WEBPACK_IMPORTED_MODULE_1__.RechazarPage]
    })
], RechazarPageModule);



/***/ }),

/***/ 1691:
/*!*******************************************!*\
  !*** ./src/app/rechazar/rechazar.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RechazarPage": () => (/* binding */ RechazarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _rechazar_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./rechazar.page.html?ngResource */ 5276);
/* harmony import */ var _rechazar_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rechazar.page.scss?ngResource */ 9229);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 124);





let RechazarPage = class RechazarPage {
    constructor(router) {
        this.router = router;
    }
    ngOnInit() {
    }
    Inicio() {
        console.log("clickity click!");
        this.router.navigate(['/home']);
    }
};
RechazarPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__.Router }
];
RechazarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-rechazar',
        template: _rechazar_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_rechazar_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RechazarPage);



/***/ }),

/***/ 9229:
/*!********************************************************!*\
  !*** ./src/app/rechazar/rechazar.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "#mensajes-rechazo {\n  width: 90%;\n  margin: 0 auto;\n  margin-bottom: 3em;\n}\n#mensajes-rechazo ion-button {\n  margin: 0.4em;\n}\n#contenedor-tachita {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  margin: 0 auto;\n  width: 80%;\n  height: 608px;\n}\n#tachita {\n  width: 140px;\n  height: 140px;\n  margin-bottom: 4em;\n}\nh2 {\n  margin-top: 2em;\n}\nh4 {\n  margin: 0;\n}\n.enviar {\n  font-size: 1.2em;\n  height: 4em;\n  width: 90%;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlY2hhemFyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtBQUVSO0FBQ0E7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtBQUVKO0FBQUE7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBR0o7QUFEQTtFQUNJLGVBQUE7QUFJSjtBQUZBO0VBQ0ksU0FBQTtBQUtKO0FBSEE7RUFDSSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQU1KIiwiZmlsZSI6InJlY2hhemFyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIiNtZW5zYWplcy1yZWNoYXpvIHtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIG1hcmdpbi1ib3R0b206IDNlbTtcclxuICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgIG1hcmdpbjogMC40ZW07XHJcbiAgICB9XHJcbn1cclxuI2NvbnRlbmVkb3ItdGFjaGl0YSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICB3aWR0aDogODAlO1xyXG4gICAgaGVpZ2h0OiA2MDhweDtcclxufVxyXG4jdGFjaGl0YSB7XHJcbiAgICB3aWR0aDogMTQwcHg7XHJcbiAgICBoZWlnaHQ6IDE0MHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNGVtO1xyXG59XHJcbmgye1xyXG4gICAgbWFyZ2luLXRvcDogMmVtO1xyXG59XHJcbmg0IHtcclxuICAgIG1hcmdpbjowO1xyXG59XHJcbi5lbnZpYXIge1xyXG4gICAgZm9udC1zaXplOiAxLjJlbTtcclxuICAgIGhlaWdodDogNGVtO1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59Il19 */";

/***/ }),

/***/ 5276:
/*!********************************************************!*\
  !*** ./src/app/rechazar/rechazar.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <ion-icon name=\"close\" id=\"flechita-atras\" (click)=\"Inicio()\"></ion-icon>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div id=\"contenedor-tachita\">\r\n    <ion-icon name=\"close-outline\" color=\"danger\" id=\"tachita\"></ion-icon>\r\n  </div>\r\n\r\n  <div id=\"container\">\r\n    <h2>Haz rechazado la invitación de Melany Jiménez</h2>\r\n    <h4>Avisa a tu amigo porqué no podrás asistir</h4>\r\n    <br>\r\n    <br>\r\n    <div id=\"mensajes-rechazo\">\r\n      <ion-button color=\"primary\" expand=\"round\">Sorry, i'm short of money</ion-button>\r\n      <ion-button color=\"primary\" expand=\"round\">Im bussy right now</ion-button>\r\n      <ion-button color=\"primary\" expand=\"round\">I'm not really hungry</ion-button>\r\n      <ion-button color=\"primary\" expand=\"round\">I can't go at that hour</ion-button>\r\n      <ion-button color=\"primary\" expand=\"round\">I don't like that restaurant</ion-button>\r\n    </div>\r\n\r\n    <ion-button class=\"enviar\" color=\"secondary\"size=\"round\" (click)=\"Inicio(inicio)\">Enviar</ion-button>\r\n  </div>\r\n</ion-content>\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_rechazar_rechazar_module_ts.js.map