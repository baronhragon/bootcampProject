"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_registro-restaurant_registro-restaurant_module_ts"],{

/***/ 8526:
/*!***************************************************************************!*\
  !*** ./src/app/registro-restaurant/registro-restaurant-routing.module.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroRestaurantPageRoutingModule": () => (/* binding */ RegistroRestaurantPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _registro_restaurant_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-restaurant.page */ 270);




const routes = [
    {
        path: '',
        component: _registro_restaurant_page__WEBPACK_IMPORTED_MODULE_0__.RegistroRestaurantPage
    }
];
let RegistroRestaurantPageRoutingModule = class RegistroRestaurantPageRoutingModule {
};
RegistroRestaurantPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegistroRestaurantPageRoutingModule);



/***/ }),

/***/ 4491:
/*!*******************************************************************!*\
  !*** ./src/app/registro-restaurant/registro-restaurant.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroRestaurantPageModule": () => (/* binding */ RegistroRestaurantPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _registro_restaurant_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-restaurant-routing.module */ 8526);
/* harmony import */ var _registro_restaurant_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-restaurant.page */ 270);







let RegistroRestaurantPageModule = class RegistroRestaurantPageModule {
};
RegistroRestaurantPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _registro_restaurant_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegistroRestaurantPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule
        ],
        declarations: [_registro_restaurant_page__WEBPACK_IMPORTED_MODULE_1__.RegistroRestaurantPage]
    })
], RegistroRestaurantPageModule);



/***/ }),

/***/ 270:
/*!*****************************************************************!*\
  !*** ./src/app/registro-restaurant/registro-restaurant.page.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegistroRestaurantPage": () => (/* binding */ RegistroRestaurantPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _registro_restaurant_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./registro-restaurant.page.html?ngResource */ 793);
/* harmony import */ var _registro_restaurant_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./registro-restaurant.page.scss?ngResource */ 2982);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ 4497);
/* harmony import */ var _service_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service.service */ 9353);







let RegistroRestaurantPage = class RegistroRestaurantPage {
    constructor(api, formBuilder, sanitizer) {
        this.api = api;
        this.formBuilder = formBuilder;
        this.sanitizer = sanitizer;
        this.results = [];
        this.nameImg = "";
        this.registerRestaurantForm = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            nameRestaurant: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            address: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            phone: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            rType: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            openLocal: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            closeLocal: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            lat: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            lng: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            shortDescription: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
            longDescription: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(),
        });
    }
    ngOnInit() {
    }
    onFile(event) {
        console.log(event);
        const [file] = event.target.files;
        this.dataImg = {
            fileRaw: file,
            fileName: file.name
        };
    }
    upload() {
        const data = new FormData();
        data.append('usrimage', this.dataImg.fileRaw);
        this.api.postImages(data).subscribe((resposeFromTheServer) => {
            let resposeLocal;
            resposeFromTheServer = resposeLocal;
        });
    }
    guardar() {
        let dataRestaurant = {
            nameRestaurant: this.registerRestaurantForm.value.nameRestaurant,
            address: this.registerRestaurantForm.value.address,
            phone: this.registerRestaurantForm.value.phone,
            rType: this.registerRestaurantForm.value.rType,
            openLocal: this.registerRestaurantForm.value.openLocal,
            closeLocal: this.registerRestaurantForm.value.closeLocal,
            lat: this.registerRestaurantForm.value.lat,
            lng: this.registerRestaurantForm.value.lng,
            shortDescription: this.registerRestaurantForm.value.shortDescription,
            longDescription: this.registerRestaurantForm.value.longDescription,
            img: this.dataImg.fileName,
        };
        this.api.restaurantPost(dataRestaurant).subscribe((responseFromTheServer) => {
            let responseLocal;
            responseLocal = responseFromTheServer;
        });
        this.upload();
        this.registerRestaurantForm.reset();
    }
};
RegistroRestaurantPage.ctorParameters = () => [
    { type: _service_service__WEBPACK_IMPORTED_MODULE_2__.ApiService },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormBuilder },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__.DomSanitizer }
];
RegistroRestaurantPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-registro-restaurant',
        template: _registro_restaurant_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_registro_restaurant_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegistroRestaurantPage);



/***/ }),

/***/ 2982:
/*!******************************************************************************!*\
  !*** ./src/app/registro-restaurant/registro-restaurant.page.scss?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJyZWdpc3Ryby1yZXN0YXVyYW50LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 793:
/*!******************************************************************************!*\
  !*** ./src/app/registro-restaurant/registro-restaurant.page.html?ngResource ***!
  \******************************************************************************/
/***/ ((module) => {

module.exports = "\r\n<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Header</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form  [formGroup]=\"registerRestaurantForm\" (ngSubmit)=\"guardar()\">\r\n    \r\n  <ion-item>\r\n    <ion-label> Full name </ion-label>\r\n    <ion-input  formControlName=\"nameRestaurant\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> Address </ion-label>\r\n    <ion-input formControlName=\"address\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> Phone </ion-label>\r\n    <ion-input formControlName=\"phone\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> rType </ion-label>\r\n    <ion-input formControlName=\"rType\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> openLocal </ion-label>\r\n    <ion-input formControlName=\"openLocal\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> closeLocal </ion-label>\r\n    <ion-input formControlName=\"closeLocal\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> latitude </ion-label>\r\n    <ion-input formControlName=\"lat\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> longitud </ion-label>\r\n    <ion-input formControlName=\"lng\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> short Description </ion-label>\r\n    <ion-input formControlName=\"shortDescription\"></ion-input>\r\n  </ion-item>\r\n\r\n  <ion-item>\r\n    <ion-label> Long Description </ion-label>\r\n    <ion-input formControlName=\"longDescription\"></ion-input>\r\n  </ion-item>\r\n</form>\r\n\r\n  <ion-item>\r\n    <ion-label> Image </ion-label>\r\n    <ion-input type=\"file\" (change)=\"onFile($event)\" ></ion-input>\r\n  </ion-item>\r\n\r\n<ion-button id=\"buttom\" (click)=\"guardar()\"  expand=\"block\" shape=\"round\">Create</ion-button>\r\n  \r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_registro-restaurant_registro-restaurant_module_ts.js.map