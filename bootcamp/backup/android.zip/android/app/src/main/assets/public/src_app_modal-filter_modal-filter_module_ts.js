"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_modal-filter_modal-filter_module_ts"],{

/***/ 307:
/*!*************************************************************!*\
  !*** ./src/app/modal-filter/modal-filter-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalFilterPageRoutingModule": () => (/* binding */ ModalFilterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _modal_filter_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-filter.page */ 9351);




const routes = [
    {
        path: '',
        component: _modal_filter_page__WEBPACK_IMPORTED_MODULE_0__.ModalFilterPage
    }
];
let ModalFilterPageRoutingModule = class ModalFilterPageRoutingModule {
};
ModalFilterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ModalFilterPageRoutingModule);



/***/ }),

/***/ 4769:
/*!*****************************************************!*\
  !*** ./src/app/modal-filter/modal-filter.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalFilterPageModule": () => (/* binding */ ModalFilterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _modal_filter_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-filter-routing.module */ 307);
/* harmony import */ var _modal_filter_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-filter.page */ 9351);







let ModalFilterPageModule = class ModalFilterPageModule {
};
ModalFilterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _modal_filter_routing_module__WEBPACK_IMPORTED_MODULE_0__.ModalFilterPageRoutingModule
        ],
        declarations: [_modal_filter_page__WEBPACK_IMPORTED_MODULE_1__.ModalFilterPage]
    })
], ModalFilterPageModule);



/***/ }),

/***/ 9351:
/*!***************************************************!*\
  !*** ./src/app/modal-filter/modal-filter.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalFilterPage": () => (/* binding */ ModalFilterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _modal_filter_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-filter.page.html?ngResource */ 7844);
/* harmony import */ var _modal_filter_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal-filter.page.scss?ngResource */ 3365);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let ModalFilterPage = class ModalFilterPage {
    constructor() { }
    ngOnInit() {
    }
};
ModalFilterPage.ctorParameters = () => [];
ModalFilterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-modal-filter',
        template: _modal_filter_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_modal_filter_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalFilterPage);



/***/ }),

/***/ 3365:
/*!****************************************************************!*\
  !*** ./src/app/modal-filter/modal-filter.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-item.line {\n  --border-color:var(--ion-color-light);\n}\n\nion-item {\n  --border-color:transparent;\n}\n\n.contenedor {\n  padding-top: 1em;\n  padding-bottom: 1em;\n}\n\nion-radio {\n  --size: 2em;\n}\n\nh2 {\n  font-size: 2.8vh;\n  font-weight: bold;\n}\n\nh3 {\n  font-size: 2vh;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1vZGFsLWZpbHRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQ0FBQTtBQUNKOztBQUNBO0VBQ0ksMEJBQUE7QUFFSjs7QUFBQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUFHSjs7QUFEQTtFQUNJLFdBQUE7QUFJSjs7QUFGQTtFQUNJLGdCQUFBO0VBQ0EsaUJBQUE7QUFLSjs7QUFIQTtFQUNJLGNBQUE7QUFNSiIsImZpbGUiOiJtb2RhbC1maWx0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWl0ZW0ubGluZSB7XHJcbiAgICAtLWJvcmRlci1jb2xvcjp2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG59XHJcbmlvbi1pdGVtIHtcclxuICAgIC0tYm9yZGVyLWNvbG9yOnRyYW5zcGFyZW50O1xyXG59XHJcbi5jb250ZW5lZG9yIHtcclxuICAgIHBhZGRpbmctdG9wOiAxZW07XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMWVtO1xyXG59XHJcbmlvbi1yYWRpbyB7XHJcbiAgICAtLXNpemU6IDJlbTtcclxufVxyXG5oMiB7XHJcbiAgICBmb250LXNpemU6IDIuOHZoO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuaDMge1xyXG4gICAgZm9udC1zaXplOiAydmg7XHJcbn1cclxuXHJcblxyXG4iXX0= */";

/***/ }),

/***/ 7844:
/*!****************************************************************!*\
  !*** ./src/app/modal-filter/modal-filter.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header [translucent]=\"true\">\r\n  <ion-toolbar>\r\n    <div class=\"header\">\r\n      <ion-back-button defaultHref=\"/\">\r\n        <ion-icon name=\"close\" id=\"flechita-atras\"></ion-icon>\r\n      </ion-back-button>\r\n    </div>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"contenedor\">\r\n  <h1 class=\"title\">Filters</h1>\r\n  <p class=\"description\">Select your restaurant filters</p>\r\n\r\n  <ion-list>\r\n    <ion-radio-group name=\"sort\" value=\"sort\">\r\n      <ion-list-header>\r\n        <ion-label><h2>Sort</h2></ion-label>\r\n      </ion-list-header>\r\n      <ion-item>\r\n        <ion-label><h3>Best visited</h3></ion-label>\r\n        <ion-radio value=\"bestVisited\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>Most popular</h3></ion-label>\r\n        <ion-radio value=\"popular\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item class=\"line\">\r\n        <ion-label><h3>Closest</h3></ion-label>\r\n        <ion-radio value=\"closest\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n  <ion-list>\r\n    <ion-radio-group name=\"type\" value=\"type\">\r\n      <ion-list-header>\r\n        <ion-label><h2>Type</h2></ion-label>\r\n      </ion-list-header>\r\n      <ion-item>\r\n        <ion-label><h3>Mexican</h3></ion-label>\r\n        <ion-radio value=\"Mexican\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>American</h3></ion-label>\r\n        <ion-radio value=\"American\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>Japanese</h3></ion-label>\r\n        <ion-radio value=\"Japanese\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>Korean</h3></ion-label>\r\n        <ion-radio value=\"korean\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>Italian</h3></ion-label>\r\n        <ion-radio value=\"Italian\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-label><h3>Arabic</h3></ion-label>\r\n        <ion-radio value=\"Arabic\"></ion-radio>\r\n      </ion-item>\r\n      <ion-item class=\"line\">\r\n        <ion-label><h3>Brazilian</h3></ion-label>\r\n        <ion-radio value=\"Brazilian\"></ion-radio>\r\n      </ion-item>\r\n    </ion-radio-group>\r\n  </ion-list>\r\n\r\n\r\n  <ion-item-group name=\"cost\" value=\"cost\">\r\n    <ion-list-header>\r\n      <ion-label><h2>Cost</h2></ion-label>\r\n    </ion-list-header>\r\n    \r\n    <ion-item>\r\n      <ion-range min=\"-200\" max=\"200\" color=\"secondary\">\r\n        <ion-label slot=\"start\"><h3>200 MXN</h3></ion-label>\r\n        <ion-label slot=\"end\"><h3>10000 MXN</h3></ion-label>\r\n      </ion-range>\r\n    </ion-item>\r\n  </ion-item-group>\r\n</div>\r\n</ion-content>\r\n\r\n<ion-footer class=\"footer\">\r\n    <ion-button shape=\"round\" color=\"secondary\">Search</ion-button>\r\n</ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_modal-filter_modal-filter_module_ts.js.map