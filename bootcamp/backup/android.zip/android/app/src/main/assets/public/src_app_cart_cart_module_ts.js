"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_cart_cart_module_ts"],{

/***/ 3951:
/*!*********************************************!*\
  !*** ./src/app/cart/cart-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageRoutingModule": () => (/* binding */ CartPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.page */ 4612);




const routes = [
    {
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_0__.CartPage
    }
];
let CartPageRoutingModule = class CartPageRoutingModule {
};
CartPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CartPageRoutingModule);



/***/ }),

/***/ 2943:
/*!*************************************!*\
  !*** ./src/app/cart/cart.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPageModule": () => (/* binding */ CartPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart-routing.module */ 3951);
/* harmony import */ var _cart_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart.page */ 4612);







let CartPageModule = class CartPageModule {
};
CartPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__.CartPageRoutingModule
        ],
        declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_1__.CartPage]
    })
], CartPageModule);



/***/ }),

/***/ 4612:
/*!***********************************!*\
  !*** ./src/app/cart/cart.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CartPage": () => (/* binding */ CartPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _cart_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cart.page.html?ngResource */ 3098);
/* harmony import */ var _cart_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cart.page.scss?ngResource */ 4068);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let CartPage = class CartPage {
    constructor() {
        this.order = JSON.parse(localStorage.getItem('order'));
    }
    ngOnInit() {
    }
    totalAmount() {
        let total = 0;
        for (let item of this.order) {
            total += item.quantity * item.price;
        }
        return total;
    }
    sendOrderToRestaurant() {
        //TODO: Endpoint for sending info to cart
        console.log("Sending this order to restaurant:\n\t", this.order);
    }
};
CartPage.ctorParameters = () => [];
CartPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-cart',
        template: _cart_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_cart_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CartPage);



/***/ }),

/***/ 4068:
/*!************************************************!*\
  !*** ./src/app/cart/cart.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = ".header-restaurante {\n  height: 20em;\n  width: 100% !important;\n  background-size: cover;\n  background-repeat: no-repeat;\n  background-position: center center;\n  border-radius: 0 0 2em 2em;\n  box-shadow: 0em 0.2em 0.6em var(--ion-color-medium);\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n}\n.header-restaurante .info-restaurante {\n  text-align: center;\n}\n.header-restaurante .info-restaurante h1, .header-restaurante .info-restaurante h2, .header-restaurante .info-restaurante h3, .header-restaurante .info-restaurante h4 {\n  color: var(--ion-color-light);\n  margin: 0;\n}\n.header-restaurante .info-restaurante h1 {\n  font-size: 4vh;\n}\n.header-restaurante .info-restaurante .nombre-restaurante {\n  padding-top: 1em;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 2em;\n}\n.header-restaurante .info-restaurante .nombre-restaurante ion-icon {\n  margin: 0;\n  padding: 0;\n  margin-left: 0.2em;\n}\n.header-restaurante .info-restaurante .descripcion-restaurante .flex {\n  display: flex;\n  gap: 1em;\n  justify-content: center;\n  align-items: center;\n}\nion-toolbar.busqueda-carta {\n  padding-top: 1em;\n}\n.carta ion-card {\n  box-shadow: none !important;\n}\n.carta ion-card ion-card-title h3 {\n  font-size: 2.6vh;\n}\n.carta ion-card ion-card-subtitle h3 {\n  font-size: 2.2vh;\n}\n.carta ion-card p {\n  font-size: 1.8vh;\n}\n.carta h2 {\n  padding: 1em 0 1em 0;\n}\n.carta .platillo {\n  padding-bottom: 1em;\n  border-bottom: 1px solid var(--ion-color-light);\n}\n.carta .platillo img {\n  object-fit: cover;\n  height: 100%;\n  width: 100%;\n  border-radius: 2em;\n}\n.carta .platillo h3 {\n  font-size: 1.8em;\n  margin: 0;\n}\n.carta .platillo p {\n  margin: 0;\n}\n.carta #add {\n  position: absolute;\n  top: 230px;\n  right: 10px;\n  z-index: 1;\n}\n.carta #remove {\n  position: absolute;\n  top: 230px;\n  right: 200px;\n  z-index: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLHNCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLGtDQUFBO0VBQ0EsMEJBQUE7RUFDQSxtREFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFDSjtBQUFJO0VBQ0ksa0JBQUE7QUFFUjtBQURRO0VBQ0ksNkJBQUE7RUFDQSxTQUFBO0FBR1o7QUFEUTtFQUNJLGNBQUE7QUFHWjtBQURRO0VBQ0ksZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFFBQUE7QUFHWjtBQUZZO0VBQ0ksU0FBQTtFQUNBLFVBQUE7RUFDQSxrQkFBQTtBQUloQjtBQUFZO0VBQ0ksYUFBQTtFQUNBLFFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBRWhCO0FBR0E7RUFDSSxnQkFBQTtBQUFKO0FBR0k7RUFDSSwyQkFBQTtBQUFSO0FBRVk7RUFDSSxnQkFBQTtBQUFoQjtBQUlZO0VBQ0ksZ0JBQUE7QUFGaEI7QUFLUTtFQUNJLGdCQUFBO0FBSFo7QUFNSTtFQUNJLG9CQUFBO0FBSlI7QUFNSTtFQUNJLG1CQUFBO0VBQ0EsK0NBQUE7QUFKUjtBQUtRO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBSFo7QUFLUTtFQUNJLGdCQUFBO0VBQ0EsU0FBQTtBQUhaO0FBS1E7RUFDSSxTQUFBO0FBSFo7QUFNSTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FBSlI7QUFNSTtFQUNJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FBSlIiLCJmaWxlIjoiY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLXJlc3RhdXJhbnRlIHtcclxuICAgIGhlaWdodDogMjBlbTtcclxuICAgIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlciBjZW50ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwIDAgMmVtIDJlbTtcclxuICAgIGJveC1zaGFkb3c6IDBlbSAwLjJlbSAwLjZlbSB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgLmluZm8tcmVzdGF1cmFudGUge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICBoMSxoMixoMyxoNCB7XHJcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGgxIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA0dmg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5ub21icmUtcmVzdGF1cmFudGUge1xyXG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMWVtO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgZ2FwOiAyZW07XHJcbiAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMC4yZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLmRlc2NyaXBjaW9uLXJlc3RhdXJhbnRlIHtcclxuICAgICAgICAgICAgLmZsZXgge1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIGdhcDogMWVtO1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbmlvbi10b29sYmFyLmJ1c3F1ZWRhLWNhcnRhIHtcclxuICAgIHBhZGRpbmctdG9wOiAxZW07XHJcbn1cclxuLmNhcnRhIHtcclxuICAgIGlvbi1jYXJkIHtcclxuICAgICAgICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaW9uLWNhcmQtdGl0bGUge1xyXG4gICAgICAgICAgICBoMyB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDIuNnZoO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi1jYXJkLXN1YnRpdGxlIHtcclxuICAgICAgICAgICAgaDMge1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAyLjJ2aDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBwIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxLjh2aDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBoMiB7XHJcbiAgICAgICAgcGFkZGluZzogMWVtIDAgMWVtIDA7XHJcbiAgICB9XHJcbiAgICAucGxhdGlsbG8ge1xyXG4gICAgICAgIHBhZGRpbmctYm90dG9tOiAxZW07XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICAgICAgaW1nIHtcclxuICAgICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDJlbTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaDMge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEuOGVtO1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgI2FkZHtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgdG9wOiAyMzBweDtcclxuICAgICAgICByaWdodDogMTBweDtcclxuICAgICAgICB6LWluZGV4OiAxO1xyXG4gICAgfVxyXG4gICAgI3JlbW92ZXtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgdG9wOiAyMzBweDtcclxuICAgICAgICByaWdodDogMjAwcHg7XHJcbiAgICAgICAgei1pbmRleDogMTtcclxuICAgIH1cclxufSJdfQ== */";

/***/ }),

/***/ 3098:
/*!************************************************!*\
  !*** ./src/app/cart/cart.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-card *ngFor=\"let item of order\">\n    <ion-card-header>\n      <ion-card-subtitle>Card Subtitle</ion-card-subtitle>\n      <ion-card-title>{{item.nameProduct}}</ion-card-title>\n    </ion-card-header>\n  \n    <ion-card-content>\n      Keep close to Nature's heart... and break clear away, once in awhile,\n      and climb a mountain or spend a week in the woods. Wash your spirit clean.\n    </ion-card-content>\n  </ion-card>\n\n</ion-content> -->\n\n<!-- ============================================ -->\n\n<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <div class=\"header\">\n      <ion-icon name=\"close\" id=\"flechita-atras\" (click)=\"Home()\"></ion-icon>\n    </div>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div class=\"contenedor\">\n\n  <h1 class=\"title\">Order</h1>\n\n  <div class=\"carta\" *ngFor=\"let item of order\">\n    <ion-card class=\"platillo\">\n      <ion-grid>\n        <ion-row>\n          <ion-col>\n            <div class=\"platillo-info\">\n              <ion-card-title> <h3>{{item.nameProduct}} {{item.quantity}}</h3> </ion-card-title>\n              <ion-card-subtitle> <h3>{{item.price*item.quantity}} MXN</h3> </ion-card-subtitle>\n            </div>\n          </ion-col>\n      </ion-row>\n    </ion-grid>\n    </ion-card>\n  </div>\n</div>\n\n<ion-item-divider>\n  <ion-label>\n    <h2>Total</h2>\n  </ion-label>\n</ion-item-divider>\n\n<h2>  ${{totalAmount()}} MXN</h2>\n\n</ion-content>\n\n<ion-footer class=\"footer\">\n  <ion-button expand=\"round\" color=\"secondary\" (click)=\"sendOrderToRestaurant()\">Confirm Order</ion-button>\n</ion-footer>\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_cart_cart_module_ts.js.map